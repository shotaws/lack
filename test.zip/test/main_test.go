// https://teratail.com/questions/337138
package main

import (
	"testing"
	
	"log"
)

func Test(t *testing.T) {
	_, err := hello(MyEvent{"Gopher"})
	if err != nil {
		log.Fatal(err)
	}
}
